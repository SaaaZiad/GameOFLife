﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Runtime.InteropServices;
using System.Diagnostics.Contracts;
using System.Collections.Specialized;
namespace GameOfLife
{
    public partial class Form1 : Form
    {
        [DllImport("winmm.dll")]
        public static extern int waveOutSetVolume(IntPtr hwo, uint dwVolume);
        [DllImport("shlwapi.dll")]
        public static extern int ColorHLSToRGB(int H, int L, int S);


        private Graphics graphics;
        private int resolution;
        private bool[,] field;
        private int rows;
        private int cols;
        private int currentGeneration = 0;
        int curralivecells = 0;
        int averagecolor = 0;
        private SoundPlayer player;

        public Form1()
        {
            InitializeComponent();
            InitializeSound();
            Text = $"Game Of Life";
        }
        private void InitializeSound()
        {
            // Create an instance of the SoundPlayer class.
            player = new SoundPlayer();
        }
        private void StartGame()
        {
            if (timer1.Enabled)
            { return; }

            currentGeneration = 0;
            curralivecells = 0;
            nudResolution.Enabled = false;
            nudDensity.Enabled = false;
            nudTime.Enabled = false;
            comboBox1.Enabled = false;
            nudLeft.Enabled = false;
            nudRight.Enabled = false;
            musicCombo.Enabled = false;

            nudLeft.Maximum = Math.Max(nudRight.Value - 1, 0);
            timer1.Interval = (int)nudTime.Value;
            resolution = (int)nudResolution.Value;
            rows = pictureBox1.Height / resolution;
            cols = pictureBox1.Width / resolution;
            field = new bool[cols, rows];
            Random random = new Random();
            int averagecolor = random.Next(50, 200);
            for (int x = 0; x < cols; x++)
            {
                for (int y = 0; y < rows; y++)
                {
                    field[x, y] = random.Next(27 - (int)nudDensity.Value) == 0;
                    if (field[x, y])
                    {
                        curralivecells++;
                    }
                }
            }
            cellAmountlabel.Text = curralivecells.ToString();
            int totalplaces = rows * cols;
            volumelabel.Text = (((double)curralivecells / (double)totalplaces) * 100).ToString("0.00");
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            graphics = Graphics.FromImage(pictureBox1.Image);
            timer1.Start();

            if(musicCombo.SelectedIndex == 0)
            {
                //player.SoundLocation = "C:\\Users\\dnsuser\\Music\\baza.wav";
                player.SoundLocation = "C:\\Users\\dnsuser\\Music\\heart_beat.wav";

            }
            else if (musicCombo.SelectedIndex == 1)
            {
                //player.SoundLocation = "C:\\Users\\dnsuser\\Music\\morgen_pablo.wav";
                player.SoundLocation = "C:\\Users\\dnsuser\\Music\\sea_sound.wav";

            }
            else if (musicCombo.SelectedIndex == 2)
            {
                //player.SoundLocation = "C:\\Users\\dnsuser\\Music\\morgen_pochemu.wav";
                player.SoundLocation = "C:\\Users\\dnsuser\\Music\\Krug_VladCent.wav";

            }
            else
            {
                //player.SoundLocation = "C:\\Users\\dnsuser\\Music\\morgen_dnb.wav";
                player.SoundLocation = "C:\\Users\\dnsuser\\Music\\bubbles_pop.wav";
            }
            player.Load();
            player.PlayLooping();
        }
        private void NextGeneration()
        {
            int totalplaces = rows * cols;
            cellAmountlabel.Text = curralivecells.ToString();
            volumelabel.Text = (((double)curralivecells / (double)totalplaces) * 100).ToString("0.00");
            curralivecells = 0;
            Random random = new Random();
            int currsat = random.Next(120, 240);
            graphics.Clear(Color.Black);

            var newField = new bool[cols, rows];
            averagecolor += 2;
            if (averagecolor > 239)
            {
                averagecolor = 0;
            }

            for (int x = 0; x < cols; x++)
            {
                for (int y = 0; y < rows; y++)
                {
                    var neighboursCount = CountNeighbours(x, y);
                    var hasLife = field[x, y];

                    if (!hasLife && neighboursCount == nudRight.Value)
                    {
                        newField[x, y] = true;
                        curralivecells++;
                    }
                    else if (hasLife && (neighboursCount < nudLeft.Value || neighboursCount > nudRight.Value))
                    {
                        newField[x, y] = false;
                    }
                    else
                    {
                        newField[x, y] = field[x, y];
                        if (field[x, y])
                        {
                            curralivecells++;
                        }
                    }

                    if (hasLife)
                    {
                        if (checkBox1.Checked)
                        {
                            SolidBrush currColor = new SolidBrush(ColorTranslator.FromWin32(ColorHLSToRGB(averagecolor, 120, 240)));
                            if (checkBox5.Checked)
                                graphics.FillEllipse(currColor, x * resolution, y * resolution, resolution, resolution);
                            else
                                graphics.FillRectangle(currColor, x * resolution, y * resolution, resolution, resolution);
                        }
                        else
                        {
                            Brush currColor = Brushes.Magenta;
                            if (checkBox5.Checked)
                                graphics.FillEllipse(currColor, x * resolution, y * resolution, resolution, resolution);
                            else
                                graphics.FillRectangle(currColor, x * resolution, y * resolution, resolution, resolution);
                        }
                    }
                }
              
            }
            field = newField;
            pictureBox1.Refresh();
            currentGeneration++;
            GenLabel.Text = currentGeneration.ToString();
            uint coeff = 0;
            coeff = (uint)(((double)curralivecells / (double)totalplaces) * 65000);
            if (!checkBox3.Checked)
            {
                coeff = Math.Max(coeff, 12500);
            }
            if(checkBox4.Checked)
            {
                coeff = 65000;
            }
            if (checkBox2.Checked)
            {
                coeff = 0;
            }
            
            SetVolume(coeff);
            volumelabel.Text = (((double)curralivecells / (double)totalplaces) * 100).ToString("0.00");
        }

        private int CountNeighbours(int x, int y)
        {
            int count = 0;
            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    var col = (x + i + cols) % cols;
                    var row = (y + j + rows) % rows;
                    var hasLife = field[col, row];
                    if (hasLife && (i != 0 || j != 0))
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        private void StopGame()
        {
            if (!timer1.Enabled)
            {
                return;
            }
            timer1.Stop();
            nudResolution.Enabled = true;
            nudDensity.Enabled = true;
            nudTime.Enabled = true;
            comboBox1.Enabled = true;
            nudLeft.Enabled = true;
            nudRight.Enabled = true;
            musicCombo.Enabled = true;
            player.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            NextGeneration();
        }

        private void bStart_Click(object sender, EventArgs e)
        {
            StartGame();
        }

        private void bStop_Click(object sender, EventArgs e)
        {
            StopGame();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!timer1.Enabled)
            {
                return;
            }
            if (e.Button == MouseButtons.Left)
            {
                var x = e.Location.X / resolution;
                var y = e.Location.Y / resolution;
                var Valid = ValidateMousePos(x, y);
                if (Valid)
                    field[x, y] = true;
            }
            if (e.Button == MouseButtons.Right)
            {
                var x = e.Location.X / resolution;
                var y = e.Location.Y / resolution;
                var Valid = ValidateMousePos(x, y);
                if (Valid)
                    field[x, y] = false;
            }
        }
        private bool ValidateMousePos(int x, int y)
        {
            return x >= 0 && y >= 0 && x < cols && y < rows;
        }

        private void Form1_Load(object sender, EventArgs e) { }

        private void bCloseGame_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0) {
                this.FormBorderStyle = FormBorderStyle.None;
                this.WindowState = FormWindowState.Maximized;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.WindowState = FormWindowState.Normal;
            }
            if (comboBox1.SelectedIndex == 2)
            {
                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.WindowState = FormWindowState.Maximized;
            }
        }
        private void SetVolume(uint volume)
        {
            waveOutSetVolume(IntPtr.Zero, volume + (volume << 16));
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void musicCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
